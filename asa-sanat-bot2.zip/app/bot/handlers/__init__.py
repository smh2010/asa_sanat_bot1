from aiogram import Router
from .start import start_router
from .help import help_router
from .unknown import unknown_router
from .job_handler import job_router

def setup_routers() -> Router:
    router = Router()
    router.include_router(start_router)
    router.include_router(help_router)
    router.include_router(job_router)
    router.include_router(unknown_router)
    return router
