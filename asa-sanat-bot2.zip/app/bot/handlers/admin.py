from aiogram import Router, types
from app.db import session
from app.models import JobPost
from app.utils.formatter import format_job_post
from aiogram.filters import Command

router = Router()

@router.message(Command("send_pending"))
async def send_pending_posts(message: types.Message):
    posts = session.query(JobPost).filter_by(sent=False).all()
    if not posts:
        await message.reply("هیچ پست جدیدی برای ارسال وجود نداره.")
        return

    count = 0
    for post in posts:
        try:
            text = format_job_post(post)
            await message.bot.send_message(chat_id="@your_target_channel", text=text)
            post.sent = True
            session.commit()
            count += 1
        except Exception as e:
            await message.reply(f"❌ خطا در ارسال پست {post.telegram_id}: {e}")

    await message.reply(f"✅ {count} پست جدید ارسال شد.")