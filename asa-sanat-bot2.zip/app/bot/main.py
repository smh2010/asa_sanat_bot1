import asyncio
import os
from aiogram import Bot, Dispatcher
from aiogram.filters import CommandStart, Command
from aiogram.types import Message
from dotenv import load_dotenv

load_dotenv('app/config/.env')

API_TOKEN = os.getenv("BOT_TOKEN")

bot = Bot(token=API_TOKEN)
dp = Dispatcher()

@dp.message(CommandStart())
async def start_handler(message: Message):
    await message.answer("سلام! به ربات خوش آمدید.\nبرای راهنمایی بیشتر دستور /help را ارسال کنید.")

@dp.message(Command(commands=["help"]))
async def help_handler(message: Message):
    await message.answer("این ربات آگهی‌ها را منتشر می‌کند و امکانات زیادی دارد.\nبرای شروع /start را بزنید.")

async def main():
    try:
        print("Bot started...")
        await dp.start_polling(bot)
    finally:
        await bot.session.close()

if __name__ == "__main__":
    asyncio.run(main())
