from aiogram import Bot, Dispatcher, types
from database.models import JobDatabase
from dotenv import load_dotenv
import os

load_dotenv('config/.env')

BOT_TOKEN = os.getenv('BOT_TOKEN')
CHANNEL = 'asasanat_job'

bot = Bot(token=BOT_TOKEN)
dp = Dispatcher(bot)
db = JobDatabase()

async def send_unsent():
    jobs = db.get_all_jobs()  # مدل اینجا تعریف شده در models.py
    for job in jobs:
        await bot.send_message(CHANNEL, job['full_text'], parse_mode='HTML')
