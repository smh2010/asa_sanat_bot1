# app/config/config.py
import os
from dotenv import load_dotenv

# مسیر ریشه پروژه
BASE_DIR = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))

# بارگذاری مقادیر از فایل .env
load_dotenv(os.path.join(BASE_DIR, "..", ".env"))

# خواندن مقادیر از محیط
API_ID = int(os.getenv("API_ID", "0"))
API_HASH = os.getenv("API_HASH", "")
BOT_TOKEN = os.getenv("BOT_TOKEN", "")
PHONE = os.getenv("PHONE", "")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL", "")
SOURCE_CHANNELS = os.getenv("CHANNELS", "").split(",")
