import asyncio
from telethon import TelegramClient
from app.database import JobPost, session
from app.config import TELEGRAM_API_ID, TELEGRAM_API_HASH, DEST_CHANNEL
from app.utils.logger import log_info, log_error

client = TelegramClient("sender", TELEGRAM_API_ID, TELEGRAM_API_HASH)

async def send_pending_posts():
    await client.start()

    pending_posts = session.query(JobPost).filter_by(status="pending").order_by(JobPost.created_at.asc()).all()

    for post in pending_posts:
        try:
            sent = await client.send_message(DEST_CHANNEL, post.text)
            post.status = "sent"
            post.dest_id = sent.id
            post.sent_at = sent.date
            session.commit()
            log_info(f"📤 Sent post {post.job_code} → ID {sent.id}")
            await asyncio.sleep(2)  # فاصله بین ارسال‌ها
        except Exception as e:
            log_error(f"❌ Failed to send {post.job_code}: {e}")
            await asyncio.sleep(1)

    await client.disconnect()
    log_info("✅ Sending complete.")

if __name__ == "__main__":
    asyncio.run(send_pending_posts())