import asyncio
from telethon import TelegramClient
from app.database import JobPost, session
from app.config import TELEGRAM_API_ID, TELEGRAM_API_HASH, DEST_CHANNEL, MAX_EDIT_AGE_HOURS
from app.utils.logger import log_info, log_error
from app.utils.formatting import generate_title, add_signature, replace_links
from datetime import datetime, timedelta

client = TelegramClient("updater", TELEGRAM_API_ID, TELEGRAM_API_HASH)
max_edit_age = timedelta(hours=MAX_EDIT_AGE_HOURS)

async def update_edited_posts():
    await client.start()

    # فقط پست‌هایی که قبلاً ارسال شدن و اخیراً ادیت شدن
    recent_posts = session.query(JobPost).filter(
        JobPost.status == "sent",
        JobPost.updated_at != None,
        JobPost.updated_at >= datetime.utcnow() - max_edit_age
    ).all()

    for post in recent_posts:
        try:
            # ساخت متن جدید
            title = generate_title(post.text)
            signed = add_signature(post.text)
            final_text = replace_links(f"{title}\n\n{signed}")

            # آپدیت پیام در کانال مقصد
            await client.edit_message(DEST_CHANNEL, post.dest_id, final_text)
            log_info(f"✏️ Updated message {post.job_code} → ID {post.dest_id}")
            await asyncio.sleep(1)
        except Exception as e:
            log_error(f"❌ Failed to update {post.job_code}: {e}")
            await asyncio.sleep(1)

    await client.disconnect()
    log_info("✅ Update complete.")

if __name__ == "__main__":
    asyncio.run(update_edited_posts())