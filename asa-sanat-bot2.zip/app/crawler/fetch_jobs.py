import asyncio
from datetime import datetime, timedelta
from telethon import TelegramClient
from app.utils.formatting import generate_title, add_signature, replace_links
from app.database import JobPost, session
from app.config import TELEGRAM_API_ID, TELEGRAM_API_HASH, SOURCE_CHANNELS, MAX_EDIT_AGE_HOURS
from app.utils.logger import log_info, log_warning
from app.utils.helpers import load_offsets, save_offsets

client = TelegramClient("crawler", TELEGRAM_API_ID, TELEGRAM_API_HASH)
max_edit_age = timedelta(hours=MAX_EDIT_AGE_HOURS)

async def fetch_and_process():
    await client.start()
    offsets = load_offsets()

    for channel in SOURCE_CHANNELS:
        last_id = offsets.get(channel, 0)
        log_info(f"📥 Reading from {channel} starting at ID {last_id}")

        async for msg in client.iter_messages(channel, min_id=last_id, reverse=True):
            if not msg.message or not msg.date:
                continue

            # بررسی ادیت‌شده بودن
            if msg.edit_date:
                if datetime.utcnow() - msg.edit_date > max_edit_age:
                    continue

            # ساخت job_code
            job_code = f"{channel}_{msg.id}"
            existing = session.query(JobPost).filter_by(job_code=job_code).first()

            # اگر قبلاً ارسال شده و ادیت‌شده نیست، رد کن
            if existing and not msg.edit_date:
                continue

            # پردازش متن
            raw_text = msg.message.strip()
            title = generate_title(raw_text)
            signed = add_signature(raw_text)
            final_text = replace_links(f"{title}\n\n{signed}")

            # ذخیره یا آپدیت در دیتابیس
            if existing:
                existing.text = final_text
                existing.updated_at = datetime.utcnow()
                log_info(f"🔄 Updated post {job_code}")
            else:
                new_post = JobPost(
                    job_code=job_code,
                    source_channel=channel,
                    source_id=msg.id,
                    text=final_text,
                    created_at=datetime.utcnow()
                )
                session.add(new_post)
                log_info(f"✅ New post saved: {job_code}")

            session.commit()
            await asyncio.sleep(2)  # فاصله بین پردازش‌ها

        # ذخیره آخرین ID
        offsets[channel] = msg.id
        save_offsets(offsets)

    await client.disconnect()
    log_info("🎉 Ingestion complete.")

if __name__ == "__main__":
    asyncio.run(fetch_and_process())