from pydantic import BaseModel
from typing import Optional

class JobResponse(BaseModel):
    id: int
    code: str
    source: str
    category: str
    text: str
    phone: Optional[str]
    created_at: str
