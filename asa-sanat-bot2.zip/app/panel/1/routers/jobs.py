from fastapi import APIRouter, Query
from typing import List, Optional
from webpanel.schemas.job import JobResponse
from webpanel.services.job_service import get_all_jobs

router = APIRouter()

@router.get("/", response_model=List[JobResponse])
def read_jobs(
    keyword: Optional[str] = Query(None),
    category: Optional[str] = Query(None)
):
    return get_all_jobs(keyword=keyword, category=category)
