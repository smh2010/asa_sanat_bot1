# app/web_panel/routes.py

from fastapi import APIRouter, Depends
from sqlalchemy.orm import Session
from typing import List
from app.database import models as db_models
from app.database.fetch_jobs import get_db
from app.web_panel.models import Job

router = APIRouter()

@router.get("/jobs", response_model=List[Job])
def get_all_jobs(db: Session = Depends(get_db)):
    jobs = db.query(db_models.Job).all()
    return jobs
