from database.models import Job
from database.session import get_session
from sqlalchemy import select
from typing import List, Optional
from datetime import datetime

def get_all_jobs(keyword: Optional[str] = None, category: Optional[str] = None) -> List[dict]:
    session = get_session()
    stmt = select(Job)
    
    if keyword:
        stmt = stmt.where(Job.text.contains(keyword))
    if category:
        stmt = stmt.where(Job.category == category)

    jobs = session.execute(stmt).scalars().all()
    return [
        {
            "id": job.id,
            "code": job.code,
            "source": job.source,
            "category": job.category,
            "text": job.text,
            "phone": job.phone,
            "created_at": job.created_at.strftime("%Y-%m-%d %H:%M")
        }
        for job in jobs
    ]
