from fastapi import FastAPI
from webpanel.routers import jobs

app = FastAPI(
    title="AsaSanat Web Panel",
    description="پنل مدیریتی آگهی‌های استخدامی",
    version="1.0.0"
)

app.include_router(jobs.router, prefix="/jobs", tags=["Jobs"])
