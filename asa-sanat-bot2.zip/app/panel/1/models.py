# app/web_panel/models.py

from pydantic import BaseModel
from typing import Optional
from datetime import datetime

class Job(BaseModel):
    id: int
    source: str
    code: str
    title: str
    content: str
    category: str
    phone_number: Optional[str] = None
    published_at: Optional[datetime] = None
    created_at: Optional[datetime] = None

    class Config:
        orm_mode = True
