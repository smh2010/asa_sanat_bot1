from fastapi import APIRouter
from app.db import session
from app.models import JobPost
from app.utils.formatter import format_job_post
from aiogram import Bot

router = APIRouter()
bot = Bot(token="YOUR_BOT_TOKEN")
TARGET_CHANNEL = "@your_target_channel"

@router.post("/send-pending")
async def send_pending_posts():
    posts = session.query(JobPost).filter_by(sent=False).all()
    if not posts:
        return {"status": "no_posts", "message": "هیچ پست جدیدی برای ارسال وجود نداره."}

    count = 0
    for post in posts:
        try:
            text = format_job_post(post)
            await bot.send_message(chat_id=TARGET_CHANNEL, text=text)
            post.sent = True
            session.commit()
            count += 1
        except Exception as e:
            print(f"❌ خطا در ارسال پست {post.telegram_id}: {e}")

    return {"status": "success", "sent_count": count}