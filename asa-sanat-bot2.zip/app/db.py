# /root/asa_sanat_bot/app/db.py

from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.models import Base
from app.config import DB_PATH  # فقط از config بخونه

# ساخت engine فقط یک‌بار
engine = create_engine(DB_PATH, echo=False)

# ساخت session factory
SessionLocal = sessionmaker(autocommit=False, autoflush=False, bind=engine)

# ساخت session برای استفاده در فایل‌های دیگر
session = SessionLocal()

# تابع ساخت جدول‌ها
def init_db():
    Base.metadata.create_all(engine)
    print("✅ دیتابیس ساخته شد و جدول‌ها آماده‌ان.")

# اجرای مستقیم برای تست
if __name__ == "__main__":
    init_db()