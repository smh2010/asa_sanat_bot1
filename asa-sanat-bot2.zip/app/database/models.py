from sqlalchemy import Column, String, Integer, DateTime, Text
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class JobPost(Base):
    __tablename__ = "job_posts"

    id = Column(Integer, primary_key=True)
    job_code = Column(String, unique=True, index=True)  # مثل: channel_12345
    source_channel = Column(String)
    source_id = Column(Integer)
    dest_id = Column(Integer, nullable=True)  # پیام ارسال‌شده در کانال مقصد
    text = Column(Text)
    status = Column(String, default="pending")  # pending, sent
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, nullable=True)
    sent_at = Column(DateTime, nullable=True)