from sqlalchemy import create_engine
from sqlalchemy.orm import sessionmaker
from app.database.models import Base

engine = create_engine("sqlite:///jobs.db", echo=False)
Session = sessionmaker(bind=engine)
session = Session()

# فقط یک بار اجرا بشه برای ساخت جدول‌ها
def init_db():
    Base.metadata.create_all(engine)