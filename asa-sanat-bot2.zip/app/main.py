# app/main.py
import asyncio
import os
import logging
from typing import List, Union, Optional

from dotenv import load_dotenv
from aiogram import Bot
from telethon import TelegramClient
from telethon.errors import RPCError
from sqlalchemy.exc import IntegrityError

from app.ingestor import fetch_latest_posts, resolve_entity
from app.db import session, init_db
from app.models import JobPost
from app.utils.formatter import format_post  # قالب نهایی فرمتینگ

# 🎛 تنظیمات لاگ
logging.basicConfig(level=logging.INFO, format="%(asctime)s | %(levelname)s | %(message)s")
logger = logging.getLogger(__name__)

# بارگذاری از .env
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=env_path)

BOT_TOKEN = os.getenv("BOT_TOKEN")
TG_API_ID = int(os.getenv("TG_API_ID"))
TG_API_HASH = os.getenv("TG_API_HASH")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL", "").strip()
SOURCE_CHANNELS_RAW = os.getenv("SOURCE_CHANNELS", "")

if not BOT_TOKEN:
    raise ValueError("❌ BOT_TOKEN تنظیم نشده.")
if not TG_API_ID or not TG_API_HASH:
    raise ValueError("❌ TG_API_ID / TG_API_HASH تنظیم نشده‌اند.")

def parse_channels(raw: str) -> List[str]:
    return [c.strip().lstrip("@") for c in raw.split(",") if c.strip()]

CHANNELS = parse_channels(SOURCE_CHANNELS_RAW)
if not CHANNELS:
    raise ValueError("❌ هیچ کانال منبعی تعریف نشده.")

def _as_int_chat_id_if_possible(raw: str) -> Optional[int]:
    r = raw.strip()
    if r.startswith("-100") and r[1:].isdigit():
        try:
            return int(r)
        except ValueError:
            return None
    return None

async def resolve_target_chat_id(client: TelegramClient, raw_target: str) -> Union[int, str]:
    int_id = _as_int_chat_id_if_possible(raw_target)
    if int_id is not None:
        logger.info(f"🎯 [TARGET_RESOLVE] TARGET_CHANNEL به صورت آیدی: {int_id}")
        return int_id

    name = raw_target.strip().lstrip("@")
    try:
        entity = await resolve_entity(client, name)
        if entity:
            full_id = int(f"-100{entity.id}")
            logger.info(f"🎯 [TARGET_RESOLVE] title={getattr(entity, 'title', None)} | id={full_id}")
            return full_id
    except RPCError as e:
        logger.error(f"❌ [TARGET_RESOLVE_ERROR] خطا در resolve: {e}")

    at_name = f"@{name}"
    logger.warning(f"⚠️ [TARGET_FALLBACK] ارسال با fallback {at_name}")
    return at_name

async def main():
    init_db()

    async with TelegramClient("session_ingestor", TG_API_ID, TG_API_HASH) as tg_client:
        async with Bot(token=BOT_TOKEN) as bot:
            target_chat = await resolve_target_chat_id(tg_client, TARGET_CHANNEL)
            if not target_chat:
                raise ValueError("❌ TARGET_CHANNEL نامعتبر است.")

            try:
                await bot.send_message(chat_id=target_chat, text="✅ Bot connected.")
                logger.info("✅ [TEST_SEND] تست ارسال به کانال هدف موفق بود.")
            except Exception as e:
                logger.error(f"❌ [TEST_SEND_ERROR] {e}")
                return

            for ch in CHANNELS:
                logger.info(f"📡 [FETCH] دریافت پیام‌ها از کانال: {ch}")
                try:
                    posts = await fetch_latest_posts(tg_client, ch, limit=3)
                    for msg in posts:
                        exists = (
                            session.query(JobPost)
                            .filter_by(telegram_id=msg.id, source_channel=ch)
                            .first()
                        )
                        if exists:
                            logger.warning(f"⚠️ [DUPLICATE] پیام {msg.id} از {ch} قبلاً ذخیره شده.")
                            continue

                        job = JobPost(
                            telegram_id=msg.id,
                            content=(msg.message or "").strip(),
                            source_channel=ch,
                            sent=False
                        )
                        try:
                            session.add(job)
                            session.commit()
                        except IntegrityError:
                            session.rollback()
                            logger.warning(f"⚠️ [DB_DUPLICATE] رکورد {msg.id} از {ch} همزمان درج شد.")
                            continue
                        except Exception as db_err:
                            session.rollback()
                            logger.error(f"❌ [DB_ERROR] در ذخیره {msg.id}: {db_err}")
                            continue

                        try:
                            formatted = format_post(job.content, include_tags=True)
                            await bot.send_message(chat_id=target_chat, text=formatted)
                            job.sent = True
                            session.commit()
                            logger.info(f"✅ [SEND_SUCCESS] ارسال {job.telegram_id} از {ch}")
                        except Exception as send_err:
                            session.rollback()
                            logger.error(f"❌ [SEND_ERROR] ارسال {job.telegram_id} ناموفق: {send_err}")
                except Exception as e:
                    logger.error(f"❌ [FETCH_ERROR] خطا در کانال {ch}: {e}")

if __name__ == "__main__":
    asyncio.run(main())