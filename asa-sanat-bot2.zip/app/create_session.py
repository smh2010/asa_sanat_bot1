from telethon.sync import TelegramClient

API_ID = int(input("Enter API_ID: "))
API_HASH = input("Enter API_HASH: ")
PHONE = input("Enter Phone Number: ")

client = TelegramClient('jobcrawler', API_ID, API_HASH)
client.connect()

if not client.is_user_authorized():
    client.send_code_request(PHONE)
    code = input('Enter the code you received: ')
    client.sign_in(PHONE, code)

print("Session created successfully!")
client.disconnect()

