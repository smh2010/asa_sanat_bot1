import json
from pathlib import Path


BASE_DIR = Path(__file__).resolve().parent
DATA_DIR = BASE_DIR / "data"

TAGS_FILE = DATA_DIR / "tags.json"
OFFSET_FILE = DATA_DIR / "offsets.json"

def load_offsets():
    if OFFSET_FILE.exists():
        with open(OFFSET_FILE, "r", encoding="utf-8") as f:
            return json.load(f)
    return {}

def save_offsets(data):
    with open(OFFSET_FILE, "w", encoding="utf-8") as f:
        json.dump(data, f, ensure_ascii=False, indent=2)