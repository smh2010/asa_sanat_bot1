# app/resender.py
import asyncio
import os
import logging
from aiogram import Bot
from dotenv import load_dotenv

from app.db import session, init_db
from app.models import JobPost
from app.utils.formatter import format_post  # یا format_job_post اگه ترجیح دادی

# بارگذاری تنظیمات از فایل env
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=env_path)

BOT_TOKEN = os.getenv("BOT_TOKEN")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL")

if not BOT_TOKEN or not TARGET_CHANNEL:
    raise ValueError("❌ BOT_TOKEN یا TARGET_CHANNEL در فایل env تنظیم نشده.")

logging.basicConfig(level=logging.INFO)
logger = logging.getLogger(__name__)

async def resend_unsent():
    init_db()
    async with Bot(token=BOT_TOKEN) as bot:
        jobs = session.query(JobPost).filter_by(sent=False).limit(10).all()
        for job in jobs:
            try:
                formatted = format_post(job.content, include_tags=True)
                await bot.send_message(chat_id=TARGET_CHANNEL, text=formatted)
                job.sent = True
                session.commit()
                logger.info(f"✅ ارسال مجدد موفق: {job.telegram_id}")
            except Exception as e:
                logger.error(f"❌ ارسال ناموفق {job.telegram_id}: {e}")

if __name__ == "__main__":
    asyncio.run(resend_unsent())