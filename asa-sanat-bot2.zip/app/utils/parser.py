import re

def clean_text(text: str) -> str:
    t = re.sub(r'(?i)(تلگرام|روبیکا)[\s:]*', '', text)
    t = re.sub(r'@([A-Za-z0-9_]+)', '@asasanat_job', t)
    t = re.sub(r'https?://(?:www\.)?t\.me/[^\s\n]+', 'https://sanatmarketing.ir', t)
    t = re.sub(r'http://telegram.me/[^\s\n]+', 'https://sanatmarketing.ir', t)
    t = re.sub(r'https?://rubika.ir/[^\s\n]+', 'https://sanatmarketing.ir', t)
    t = re.sub(r'\[([^\]]+)\]\(https?://(?:www\.)?t\.me/[^\)]+\)', r'\1(https://sanatmarketing.ir)', t)
    t = re.sub(r'Kargomar', 'ASASANAT', t)
    t = re.sub(r'👈\s*عضویت در کانال اصلی', '', t)
    t = re.sub(r'👈\s*مشاور کانال', '', t)
    t = re.sub(r'کانال‌?پاکدشت،?ورامین', '', t)
    t = re.sub(r'خبر فوری و آگهی استخدامی [^\n]+', '', t)
    t = re.sub(r'#عنوان\s+مشخص\s+نشده', '', t)
    t = re.sub(r'(@asasanat_job)(\s*\1)+', r'\1', t)
    lines = [line.strip() for line in t.split('\n') if line.strip()]
    t = '\n'.join(lines)
    return t
