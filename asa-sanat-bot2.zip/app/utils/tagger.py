import re

def extract_industry_name(text):
    match = re.search(r"(شرکت|کارخانه|واحد صنعتی)\s+([آ-یa-zA-Z0-9\-]+)", text)
    return match.group(0).strip() if match else None

def extract_job_title(text):
    jobs = ["تراشکار", "حسابدار", "برقکار", "انباردار", "مدیر تولید", "اپراتور", "جوشکار"]
    for job in jobs:
        if job in text:
            return job
    return None

def extract_location(text):
    locations = ["شهرک شمس‌آباد", "پاکدشت", "ورامین", "تهران", "شهرک صنعتی عباس‌آباد"]
    for loc in locations:
        if loc in text:
            return loc
    return None

def extract_tags(text, post_id=None):
    tags = {
        "industry": extract_industry_name(text),
        "job": extract_job_title(text),
        "location": extract_location(text),
        "post_id": post_id
    }
    return {k: v for k, v in tags.items() if v}