import re
import html

UNWANTED_NAMES = [
    "کانال پاکدشت ورامین",
    "کارگمار"
]

UNWANTED_IDS = [
    "@pakdasht_admin",
    "@kargomar",
    "@tehran_jobs",
    "@jobiran",
    "@iran_jobs",
    "@jobcenter"
]

REPLACEMENTS = {
    "@pakdasht_admin": "@asasanat_job",
    "@kargomar": "@asasanat_job",
    "@tehran_jobs": "@asasanat_job",
    "www.oldsite.com": "https://sanatmarketing.ir",
    "http://": "https://",
    "تلگرام": "سامانه"
}

KEYWORDS = [
    "استخدام تهران",
    "استخدام فوری",
    "استخدام شهرک صنعتی",
    "استخدام شهرک‌های صنعتی",
    "استخدام در تهران",
    "استخدام در پاکدشت",
    "استخدام در ورامین"
]

SIGNATURE = (
    "〰️ آساصنعت | بزرگترین سامانه استخدام و کاریابی شهرک‌های صنعتی ایران\n"
    "📢 @asasanat_job\n"
    "🔗 https://sanatmarketing.ir\n"
    "📞 09215059005"
)

def clean_text(text):
    for phrase in UNWANTED_NAMES:
        text = text.replace(phrase, "")
    for unwanted_id in UNWANTED_IDS:
        text = text.replace(unwanted_id, "")
    for old, new in REPLACEMENTS.items():
        text = text.replace(old, new)
    text = re.sub(r"[🌟🔥💥✨🎯✅❗️]+", "", text)
    return re.sub(r"\n{2,}", "\n", text.strip())

def generate_title(text):
    lines = text.strip().splitlines()
    for line in lines:
        if "استخدام" in line or "دعوت به همکاری" in line:
            return f"**📌 {html.escape(line.strip())}**"
    return "**📌 آگهی استخدام**"

def extract_tags(text):
    tags = []
    for keyword in KEYWORDS:
        if keyword in text:
            tags.append(keyword)
    return list(set(tags))  # حذف تکراری‌ها

def format_post(text, include_tags=False):
    cleaned = clean_text(text)
    title = generate_title(cleaned)
    cleaned = re.sub(r"〰️ آساصنعت.*", "", cleaned, flags=re.DOTALL)
    tags = extract_tags(cleaned)

    post = f"{title}\n\n{cleaned.strip()}\n\n{SIGNATURE}"
    
    if include_tags and tags:
        tag_line = "🏷️ " + " | ".join(tags)
        post += f"\n\n{tag_line}"

    return post