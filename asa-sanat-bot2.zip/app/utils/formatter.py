def format_post(text, include_tags=True):
    lines = [post.content]

    if post.location:
        lines.append(f"📍 محل: {post.location}")
    if post.category:
        lines.append(f"🧑‍💼 دسته‌بندی: {post.category}")
    if post.phone_number:
        lines.append(f"📞 تماس: {post.phone_number}")
    if post.tags:
        lines.append(f"🏷️ برچسب‌ها: {post.tags}")

    lines.append("\n📢 ارسال شده توسط ربات کاریابی")
    return "\n".join(lines)