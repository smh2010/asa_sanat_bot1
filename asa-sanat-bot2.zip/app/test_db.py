from db import SessionLocal

def test_db():
    session = SessionLocal()
    print("✅ دیتابیس وصل شد!")
    session.close()

test_db()
