# app/ingestor.py
import logging
from typing import List
from telethon import TelegramClient
from telethon.tl.types import Message
from telethon.errors import UsernameInvalidError, UsernameNotOccupiedError, ChannelPrivateError

logger = logging.getLogger(__name__)

def _clean(name: str) -> str:
    return name.strip().lstrip("@")

async def resolve_entity(client: TelegramClient, name: str):
    name = _clean(name)
    try:
        return await client.get_entity(name)
    except UsernameNotOccupiedError:
        logger.error(f"❌ نام کاربری وجود ندارد: {name}")
    except UsernameInvalidError:
        logger.error(f"❌ نام کاربری نامعتبر: {name}")
    except ChannelPrivateError:
        logger.error(f"❌ کانال خصوصی است یا عضو نیستی: {name}. از آیدی -100... استفاده کن.")
    except ValueError as ve:
        logger.error(f"❌ chat not found برای: {name} → {ve}")
    except Exception as e:
        logger.error(f"❌ خطای ناشناخته در resolve {name}: {e}")
    return None

async def fetch_latest_posts(client: TelegramClient, channel_username: str, limit: int = 3) -> List[Message]:
    entity = await resolve_entity(client, channel_username)
    if entity is None:
        return []
    msgs: List[Message] = []
    try:
        async for m in client.iter_messages(entity, limit=limit):
            if isinstance(m, Message) and m.message:
                msgs.append(m)
        logger.info(f"✅ {len(msgs)} پیام متنی از {channel_username} دریافت شد.")
    except Exception as e:
        logger.error(f"❌ خطا در دریافت پیام‌ها از {channel_username}: {e}")
    return msgs