import os
import asyncio
from dotenv import load_dotenv
from aiogram import Bot
from app.db import session
from app.models import JobPost
from app.utils.formatter import format_job_post

# بارگذاری .env از ریشه پروژه
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=env_path)

# گرفتن مقادیر از env
BOT_TOKEN = os.getenv("BOT_TOKEN")
TARGET_CHANNEL = os.getenv("TARGET_CHANNEL")
MAX_SEND_PER_RUN = int(os.getenv("MAX_SEND_PER_RUN", "3"))
DRY_RUN = os.getenv("DRY_RUN", "false").lower() == "true"
RATE_LIMIT_PER_MIN = int(os.getenv("RATE_LIMIT_PER_MIN", "20"))

# بررسی صحت توکن
if not BOT_TOKEN:
    raise ValueError("❌ BOT_TOKEN در فایل .env تعریف نشده یا نامعتبر است.")

bot = Bot(token=BOT_TOKEN)

async def send_unsent_posts():
    posts = session.query(JobPost).filter_by(sent=False).limit(MAX_SEND_PER_RUN).all()

    delay = 60 / max(RATE_LIMIT_PER_MIN, 1)  # فاصله بین ارسال‌ها بر اساس نرخ مجاز

    for post in posts:
        text = format_job_post(post)

        if DRY_RUN:
            print(f"🧪 DRY_RUN فعال است. پیام ارسال نمی‌شود:\n{text}\n")
        else:
            try:
                await bot.send_message(chat_id=TARGET_CHANNEL, text=text)
                post.sent = True
                session.commit()
                print(f"✅ Sent post {post.telegram_id}")
            except Exception as e:
                print(f"❌ Failed to send post {post.telegram_id}: {e}")

        await asyncio.sleep(delay)  # رعایت نرخ ارسال

if __name__ == "__main__":
    asyncio.run(send_unsent_posts())