from sqlalchemy import Column, Integer, String, Boolean, DateTime, Text, BigInteger
from sqlalchemy.ext.declarative import declarative_base
from datetime import datetime

Base = declarative_base()

class JobPost(Base):
    __tablename__ = "job_posts"

    id = Column(Integer, primary_key=True, index=True)
    telegram_id = Column(BigInteger, unique=True, nullable=False)
    content = Column(Text, nullable=False)
    source_channel = Column(String(100), nullable=False, index=True)
    sent = Column(Boolean, default=False)
    created_at = Column(DateTime, default=datetime.utcnow)
    updated_at = Column(DateTime, default=datetime.utcnow, onupdate=datetime.utcnow)

    # فیلدهای جدید
    tags = Column(String(255), nullable=True, index=True)
    location = Column(String(255), nullable=True)
    category = Column(String(255), nullable=True)
    phone_number = Column(String(50), nullable=True)