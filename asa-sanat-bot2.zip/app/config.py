import os
from dotenv import load_dotenv

# بارگذاری env از ریشه پروژه
env_path = os.path.join(os.path.dirname(__file__), '..', '.env')
load_dotenv(dotenv_path=env_path)

def get_env(name: str, default=None, required=False, cast=str):
    value = os.getenv(name, default)
    if required and value is None:
        raise ValueError(f"❌ مقدار '{name}' در فایل .env تعریف نشده.")
    try:
        return cast(value)
    except Exception:
        raise ValueError(f"❌ مقدار '{name}' قابل تبدیل به {cast.__name__} نیست.")

# مسیر پایه پروژه
BASE_DIR = os.path.abspath(os.path.join(os.path.dirname(__file__), '..'))

# تنظیمات اصلی
BOT_TOKEN = get_env("BOT_TOKEN", required=True)
TARGET_CHANNEL = get_env("TARGET_CHANNEL", required=True)
MAX_SEND_PER_RUN = get_env("MAX_SEND_PER_RUN", default=3, cast=int)
RATE_LIMIT_PER_MIN = get_env("RATE_LIMIT_PER_MIN", default=20, cast=int)
DRY_RUN = get_env("DRY_RUN", default="false", cast=lambda x: x.lower() == "true")

# مسیر فایل‌ها
TAGS_FILE = os.path.join(BASE_DIR, get_env("TAGS_FILE", default="tags.joon"))
DB_PATH = get_env("DB_PATH", default="sqlite:///jobs.db")